Exemplo sem imagens externas.
